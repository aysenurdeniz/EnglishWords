package com.example.englishwords

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_verbs.*


class Verbs : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_verbs)

        val i = intent
        per4.text = i.getStringExtra("per4")
        rep4.text = i.getStringExtra("rep4")

    }
}