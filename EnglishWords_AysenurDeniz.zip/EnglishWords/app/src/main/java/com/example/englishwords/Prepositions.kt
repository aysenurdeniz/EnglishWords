package com.example.englishwords

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_prepositions.*
import kotlinx.android.synthetic.main.activity_verbs.*
import kotlinx.android.synthetic.main.activity_verbs.per4
import kotlinx.android.synthetic.main.activity_verbs.rep4

class Prepositions : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_prepositions)

        val i = intent
        textView33.text = i.getStringExtra("textView33")
        textView34.text = i.getStringExtra("textView34")
    }
}