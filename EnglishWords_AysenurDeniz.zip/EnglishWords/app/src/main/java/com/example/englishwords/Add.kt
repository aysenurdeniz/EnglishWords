package com.example.englishwords

import android.app.AlertDialog
import android.content.DialogInterface
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.contains
import androidx.core.view.get
import kotlinx.android.synthetic.main.activity_add.*
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_verbs.*

class Add : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add)

        val stringArray = Array<String>(4){""}
        val secenekler = arrayOf("Fiil", "İsim", "Edat", "Sıfat")
        val adapter = ArrayAdapter(
                this, // Context
                android.R.layout.simple_spinner_item, // Layout
                secenekler // Array
        )
        adapter.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line)
        liste.adapter = adapter;
        liste.onItemSelectedListener = object: AdapterView.OnItemSelectedListener{
            override fun onItemSelected(parent: AdapterView<*>, view: View, position: Int, id: Long){
                stringArray[0] = parent.getItemAtPosition(position).toString();

            }

            override fun onNothingSelected(parent: AdapterView<*>){
            }
        }

        add.setOnClickListener {
            val builder = AlertDialog.Builder(this)
            builder.setTitle(R.string.dialogTitle)
            builder.setMessage(R.string.dialogMessage)
            builder.setIcon(android.R.drawable.ic_dialog_alert)

            builder.setPositiveButton("Evet"){ dialogInterface, which ->
                    if(stringArray[0].equals("Fiil")){
                        val intent = Intent(this, Verbs::class.java)
                        intent.putExtra("per4", english.text.toString())
                        intent.putExtra("rep4", turkish.text.toString())
                        startActivity(intent)
                    }else if(stringArray[0].equals("İsim")){
                        val intent = Intent(this, Nouns::class.java)
                        intent.putExtra("textView25", english.text.toString())
                        intent.putExtra("textView26", turkish.text.toString())
                        startActivity(intent)
                    }else if(stringArray[0].equals("Edat")){
                        val intent = Intent(this, Prepositions::class.java)
                        intent.putExtra("textView33", english.text.toString())
                        intent.putExtra("textView34", turkish.text.toString())
                        startActivity(intent)
                    }else if(stringArray[0].equals("Sıfat")){
                        val intent = Intent(this, Adjectives::class.java)
                        intent.putExtra("textView9", english.text.toString())
                        intent.putExtra("textView10", turkish.text.toString())
                        startActivity(intent)
                    }


                Toast.makeText(applicationContext, "Eklendi", Toast.LENGTH_LONG).show()
            }

            builder.setNeutralButton("İptal"){ dialogInterface, which ->
                Toast.makeText(applicationContext, "İptal edildi", Toast.LENGTH_LONG).show()
            }

            builder.setNegativeButton("Hayır"){ dialogInterface: DialogInterface, which ->
                Toast.makeText(applicationContext, "Hayır'a tıklandı", Toast.LENGTH_LONG).show()
            }

            val alertDialog: AlertDialog = builder.create()
            alertDialog.setCancelable(false)
            alertDialog.show()
        }
    }


}



