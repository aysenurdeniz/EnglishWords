package com.example.englishwords

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_nouns.*
import kotlinx.android.synthetic.main.activity_prepositions.*

class Nouns : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_nouns)

        val i = intent
        textView25.text = i.getStringExtra("textView25")
        textView26.text = i.getStringExtra("textView26")
    }
}