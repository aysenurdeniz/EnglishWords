package com.example.englishwords

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    fun goVerbs(view: View?) {
        val intent = Intent(this, Verbs::class.java)
        startActivity(intent)
    }

    fun goNouns(view: View?) {
        val intent = Intent(this, Nouns::class.java)
        startActivity(intent)
    }

    fun goPrepositions(view: View?) {
        val intent = Intent(this, Prepositions::class.java)
        startActivity(intent)
    }

    fun goAdjectives(view: View?) {
        val intent = Intent(this, Adjectives::class.java)
        startActivity(intent)
    }

    fun goAdd(view: View?) {
        val intent = Intent(this, Add::class.java)
        startActivity(intent)
    }

}