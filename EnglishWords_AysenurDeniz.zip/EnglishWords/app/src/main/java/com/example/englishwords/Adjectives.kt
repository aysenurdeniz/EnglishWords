package com.example.englishwords

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_adjectives.*
import kotlinx.android.synthetic.main.activity_nouns.*

class Adjectives : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_adjectives)

        val i = intent
        textView9.text = i.getStringExtra("textView9")
        textView10.text = i.getStringExtra("textView10")
    }
}